﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    public class Repository<T>
    {
        public List<T> Container { get; set; }  

        public Repository() { 
            Container = new List<T>();
        }

        public string Add(T item)
        {
            Container.Add(item);

            return "Add";
        }

        public string Delete(T item)
        {
            if (Container.Contains(item))
            {
                Container.Remove(item);
            }
           
            return "Delete";
        }

        public string Update(T newItem, T oldItem)
        {
            for (int i = 0; i < Container.Count; i++)
            {
                if (Container[i] != null && Container[i].Equals(oldItem))
                {
                    Container[i] = newItem;
                }
            }
           
            return "Update";
        }

        public string GetAll()
        {
            return "GetAll";
        }

        public T CreateNew()
        {
            var newT = default(T);
            Container.Add(newT);
            return newT;
        }
    }
}
